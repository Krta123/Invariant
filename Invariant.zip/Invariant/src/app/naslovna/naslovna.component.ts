import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-naslovna',
  templateUrl: './naslovna.component.html',
  styleUrls: ['./naslovna.component.css']
})
export class NaslovnaComponent implements OnInit {

  title = "invariant";

  nav1 = "Lista";
  nav2 = "TimeWeb";
  nav3 = "web dizajn";
  nav4 = "o nama";
  nav5 = "kontakt";

  podnaslov1 = "TimeWeb";
  podnaslov1Opis = "aplikacija koja olaksava zivot.";

  podnaslov2_1 = "IZRADA";
  podnaslov2_2 = "EXPRESS";
  podnaslov2_3 = "WEB STRANICA";
  podnaslov2Opis = "fast and furious 2018";

  podnaslov3 = "trebate web stranicu?";
  podnaslov3Opis = "na pravom ste mjestu!";

  podnaslov4 = "O NAMA";
  podnaslov4Opis = "we are so great.";

  podnaslov5 = "KONTAKTIRAJTE NAS";
  podnaslov5Opis = "otvoreni smo za prijedloge.";

  loremIpsum = "Lorem Ipsum";
  loremIpsumOpis = "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. " +
                   "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor" +
                   " in repregenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, " +
                   "sunt in culpa qui officia deserunt mollit anim id est laborum.";

  paragraf = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. " +
             "Sagittis purus sit amet volutpat consequat mauris nunc congue. Faucibus vitae aliquet nec ullamcorper sit amet. Morbi tempus " +
             "iaculis urna id volutpat lacus laoreet non curabitur. Vitae purus faucibus ornare suspendisse sed nisi lacus. Mattis enim ut " +
             "tellus elementum sagittis vitae et. Proin sed libero enim sed faucibus turpis in eu. Adipiscing elit ut aliquam purus sit. " +
             "Nunc sed augue lacus viverra vitae congue eu. Consequat mauris nunc congue nisi vitae suscipit. Fames ac turpis egestas sed " +
             "tempus urna et. Cras adipiscing enim eu turpis egestas pretium aenean pharetra. Mauris pharetra et ultrices neque. Porttitor " +
             "massa id neque aliquam vestibulum morbi blandit cursus. Sit amet consectetur adipiscing elit ut. Duis tristique sollicitudin " +
             "nibh sit amet commodo nulla. Sit amet dictum sit amet justo donec. Nam libero justo laoreet sit amet cursus sit amet dictum. " +
             "Senectus et netus et malesuada. Pharetra massa massa ultricies mi quis. Suspendisse in est ante in. Donec pretium vulputate " +
             "sapien nec sagittis aliquam malesuada bibendum arcu.";


  button1 = "SAZNAJ VISE";
  button2 = "info@invariant.hr";

  profil1 = "Profil 1";
  profil2 = "Profil 2";
  profil3 = "Profil 3";
  profil4 = "Profil 4";
  opis = "opis";


  constructor() { }

  ngOnInit(): void {
  }

}
