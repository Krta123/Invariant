import { Component, OnInit } from '@angular/core';
import { ɵangular_packages_platform_browser_dynamic_testing_testing_a } from '@angular/platform-browser-dynamic/testing';

@Component({
  selector: 'app-lista',
  templateUrl: './lista.component.html',
  styleUrls: ['./lista.component.css']
})
export class ListaComponent implements OnInit {

  title = "invariant";

  nav1 = "Lista";
  nav2 = "TimeWeb";
  nav3 = "web dizajn";
  nav4 = "o nama";
  nav5 = "kontakt";

  podnaslov1 = "Lista svih predmeta";

  id = "ID predmeta: ";
  naziv = "Naziv predmeta: ";
  opis = "Opis predmeta: ";

  obrisi = "Delete";

  dodaj = "Dodaj novi predmet";
  otkazi = "Otkazi dodavanje predmeta";
  dodaj2 = "Dodaj predmet";

  predmeti = [
    {id: 0, naziv: "Racunalo", opis:'Neki opis'},
    {id: 1, naziv: "Stol", opis:'Neki novi opis'},
    {id: 2, naziv: "Tipkovnica", opis:'Samo opis'},
    {id: 3, naziv: "Prozor", opis:'Zadnji opis'}
  ];

  noviPredmet = {
    id: 0,
    naziv: '',
    opis: ''
  };

  addPredmet = false;

  max = 0;

  constructor() { }

  ngOnInit(): void {
  }

  maxId(){
    this.predmeti.forEach(predmet =>{
      if(predmet.id > this.max){
        this.max = predmet.id;
      }
    });
    return this.max;
  }

  add(){
    this.noviPredmet.id = this.maxId() + 1;
    this.predmeti.push(this.noviPredmet);
    this.noviPredmet={id: 0, naziv: '', opis: ''};
    this.addPredmet = false;
  }

  delete(index){
    this.predmeti.splice(index, 1);
  }

  moveUp(index){
    if(index > 0){
      let tmp = this.predmeti[index];
      this.predmeti[index] = this.predmeti[index - 1];
      this.predmeti[index - 1] = tmp;
    }
  }

  moveDown(index){
    if(index < this.predmeti.length - 1){
      let tmp = this.predmeti[index];
      this.predmeti[index] = this.predmeti[index + 1];
      this.predmeti[index + 1] = tmp;
    }
  }

  AddNewPredmet(){
    this.addPredmet = !this.addPredmet;
  }

}
